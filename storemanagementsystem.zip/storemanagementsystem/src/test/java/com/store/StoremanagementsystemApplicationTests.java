package com.store;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoremanagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
